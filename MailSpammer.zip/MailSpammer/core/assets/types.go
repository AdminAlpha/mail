package assets

type DefaultJson []string // ["list"]
