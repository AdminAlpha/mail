<div id="top"></div>
<p align="center">
  <img src="https://img.shields.io/github/contributors/dropout1337/Mailman-Killer.svg?style=for-the-badge"/>
  <img src="https://img.shields.io/github/forks/dropout1337/Mailman-Killer.svg?style=for-the-badge"/>
  <img src="https://img.shields.io/github/stars/dropout1337/Mailman-Killer.svg?style=for-the-badge"/>
  <img src="https://img.shields.io/github/issues/dropout1337/Mailman-Killer.svg?style=for-the-badge"/>
  <img src="https://img.shields.io/github/license/dropout1337/Mailman-Killer.svg?style=for-the-badge"/>
</p>
  
---------------------------------------
  
<br/>
<div align="center">
  <h2 align="center">Mailman Killer</h3>

  <p align="center">
    Bomb emails with thousands of mailman nodes!
    <br />
    <br />
    <a href="https://github.com/dropout1337/Mailman-Killer/issues">Report Bug</a>
    ·
    <a href="https://github.com/dropout1337/Mailman-Killer/issues">Request Feature</a>
  </p>
</div>

<img src="https://i.imgur.com/0NVEDwq.gif"/>

### Contact
View my contact information on my [telegram](https://t.me/dropoutuwu/)

> **Warning**
> I'm not held responsible for any actions performed while using this program.
